// middleware.ts  ← place this in the PROJECT ROOT (same level as app/)
// Protects all routes. Unauthenticated users are redirected to /auth/signin.
// Public routes (signin, error, API auth callback) are explicitly excluded.

export { auth as middleware } from './lib/auth/config';

export const config = {
  matcher: [
    // Protect everything except:
    // - NextAuth internal routes
    // - Static files
    // - Public assets
    '/((?!api/auth|auth/signin|auth/error|_next/static|_next/image|favicon.ico).*)',
  ],
};
