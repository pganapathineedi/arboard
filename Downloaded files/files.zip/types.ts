// lib/clients/types.ts
// Drop this in your existing lib/ folder

export type SalesforceCloud =
  | 'Sales Cloud'
  | 'Service Cloud'
  | 'Experience Cloud'
  | 'Marketing Cloud'
  | 'Data Cloud'
  | 'Commerce Cloud'
  | 'Financial Services Cloud'
  | 'Health Cloud'
  | 'Manufacturing Cloud'
  | 'OmniStudio'
  | 'Revenue Cloud'
  | 'Agentforce';

export type RegulatoryOverlay =
  | 'HIPAA'
  | 'FSC'
  | 'GDPR'
  | 'APRA-CPS234'
  | 'SOX'
  | 'PCI-DSS'
  | 'CCPA';

export type DataRegion = 'us-east-1' | 'eu-west-1' | 'ap-southeast-2' | 'us-west-2';

export type UserRole = 'admin' | 'reviewer' | 'readonly';

export interface ClientConfig {
  clientId: string;                        // unique slug, e.g. "acme-bank"
  name: string;                            // display name
  industry: string;                        // e.g. "Financial Services"
  salesforceClouds: SalesforceCloud[];     // clouds in scope for this client
  regulatoryOverlays: RegulatoryOverlay[]; // compliance frameworks to enforce
  dataRegion: DataRegion;                  // where data is stored and processed
  knowledgeBaseId: string;                 // Supabase namespace for this client's ADRs
  monthlyBudgetUSD: number;               // hard cap — sessions blocked above this
  budgetAlertPct: number;                  // alert threshold, e.g. 80 = alert at 80%
  alertWebhookUrl?: string;               // Slack/Teams webhook for budget alerts
  zeroRetention: boolean;                  // if true, no session data persisted
  agentOverridesPath?: string;            // optional: path to agent-overrides.ts
}

// Agent prompt override — lets clients customise individual sections
// without touching base agent configs
export interface AgentPromptOverride {
  agentId: string;
  sections: Partial<{
    persona: string;
    expertise: string;
    guardrails: string;
    format: string;
    extra: string;
  }>;
}
