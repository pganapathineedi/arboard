// app/api/forum/route.ts  ← REPLACE your existing route with this
// Shows exactly how to wire costGuard + injectClientContext into the existing forum flow.
// The agent/streaming logic inside runForum() stays exactly as it is.

import { NextResponse } from 'next/server';
import { withRole } from '../../../lib/auth/rbac';
import { checkBudget, recordSessionCost } from '../../../lib/middleware/costGuard';
import { injectClientContext } from '../../../lib/middleware/injectClientContext';
import { saveADR } from '../../../lib/adr/store';
// Keep your existing imports:
// import { runForum } from '../../../lib/orchestrator/forum';

export const POST = withRole('reviewer', async (req, { clientId }) => {
  // 1. Budget gate — block before spending any tokens
  const budget = await checkBudget();
  if (!budget.allowed) {
    return NextResponse.json({ error: budget.reason }, { status: 402 });
  }

  const body = await req.json();
  const { requirement, agents, design, sessionId } = body;

  // 2. Inject client context into each agent's system prompt
  //    Call this for each agent before passing to your existing runForum()
  //    Example — adapt to your actual agent runner:
  //
  //    const enrichedAgents = await Promise.all(
  //      agents.map((agent: { id: string; systemPrompt: string }) =>
  //        injectClientContext({ agentId: agent.id, systemPrompt: agent.systemPrompt })
  //      )
  //    );

  // 3. Run the forum (your existing streaming logic — unchanged)
  //    const { stream, usage, verdict, scribeNotes, mustFixIssues } =
  //      await runForum({ requirement, agents: enrichedAgents, design, sessionId, clientId });

  // 4. After the stream completes — record cost and persist ADR
  //    (wire these into your stream completion callback)
  //
  //    await recordSessionCost(sessionId, usage);
  //
  //    await saveADR({
  //      sessionId,
  //      requirement,
  //      verdict,
  //      scribeNotes,
  //      mustFixIssues,
  //    });

  // Placeholder response — replace with your actual stream return
  return NextResponse.json({
    message: 'Wire injectClientContext + costGuard into your existing runForum() call above.',
    clientId,
  });
});

// ── Supabase table SQL (run once per client environment) ─────────────────────
//
// Run this in your Supabase SQL editor to create the required tables:
//
// CREATE TABLE session_costs (
//   id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
//   session_id  text NOT NULL,
//   client_id   text NOT NULL,
//   input_tokens  integer NOT NULL,
//   output_tokens integer NOT NULL,
//   cost_usd    numeric(10,6) NOT NULL,
//   recorded_at timestamptz NOT NULL DEFAULT now()
// );
//
// CREATE TABLE adrs (
//   id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
//   session_id       text NOT NULL,
//   client_id        text NOT NULL,
//   version          integer NOT NULL DEFAULT 1,
//   status           text NOT NULL DEFAULT 'draft',
//   requirement      text NOT NULL,
//   requirement_hash text NOT NULL,
//   verdict          text,
//   scribe_notes     text,
//   must_fix_issues  jsonb DEFAULT '[]',
//   sign_offs        jsonb DEFAULT '[]',
//   superseded_by_id uuid REFERENCES adrs(id),
//   created_at       timestamptz NOT NULL DEFAULT now(),
//   updated_at       timestamptz NOT NULL DEFAULT now()
// );
//
// -- Row Level Security: each client only sees their own data
// ALTER TABLE session_costs ENABLE ROW LEVEL SECURITY;
// ALTER TABLE adrs ENABLE ROW LEVEL SECURITY;
//
// CREATE POLICY "client_isolation_costs" ON session_costs
//   USING (client_id = current_setting('app.client_id'));
//
// CREATE POLICY "client_isolation_adrs" ON adrs
//   USING (client_id = current_setting('app.client_id'));
