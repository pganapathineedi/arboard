// lib/adr/store.ts
// Persists ADRs to Supabase with versioning, status, and sign-off tracking.
// Extends the existing SessionData type — no changes to agent or forum logic.

import { createClient } from '@supabase/supabase-js';
import { getClientConfig } from '../clients';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_ANON_KEY!
);

export type ADRStatus = 'draft' | 'approved' | 'conditions' | 'revision' | 'superseded';

export interface ADRRecord {
  id: string;
  clientId: string;
  sessionId: string;
  version: number;
  status: ADRStatus;
  requirement: string;
  verdict: string;         // full Judge verdict text
  scribeNotes: string;     // full Scribe ADR text
  mustFixIssues: string[]; // parsed from Judge output
  signOffs: SignOff[];
  createdAt: string;
  updatedAt: string;
  supersededById?: string;
}

export interface SignOff {
  userId: string;
  userName: string;
  role: string;
  signedAt: string;
}

// Save a new ADR from a completed session
export async function saveADR(params: {
  sessionId: string;
  requirement: string;
  verdict: string;
  scribeNotes: string;
  mustFixIssues: string[];
}): Promise<ADRRecord> {
  const config = await getClientConfig();

  // Get next version number for this client+requirement combo
  const version = await getNextVersion(config.clientId, params.requirement);

  // Mark any previous versions as superseded
  if (version > 1) {
    await supabase
      .from('adrs')
      .update({ status: 'superseded', updated_at: new Date().toISOString() })
      .eq('client_id', config.clientId)
      .eq('requirement_hash', hashRequirement(params.requirement))
      .neq('status', 'superseded');
  }

  const verdictLower = params.verdict.toLowerCase();
  const status: ADRStatus = verdictLower.includes('approved')
    ? 'approved'
    : verdictLower.includes('conditions')
    ? 'conditions'
    : 'revision';

  const record = {
    session_id: params.sessionId,
    client_id: config.clientId,
    version,
    status,
    requirement: params.requirement,
    requirement_hash: hashRequirement(params.requirement),
    verdict: params.verdict,
    scribe_notes: params.scribeNotes,
    must_fix_issues: params.mustFixIssues,
    sign_offs: [],
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  const { data, error } = await supabase
    .from('adrs')
    .insert(record)
    .select()
    .single();

  if (error) throw new Error(`Failed to save ADR: ${error.message}`);
  return toADRRecord(data);
}

// Add a sign-off to an existing ADR
export async function signOffADR(adrId: string, signOff: Omit<SignOff, 'signedAt'>): Promise<void> {
  const { data: adr, error } = await supabase
    .from('adrs')
    .select('sign_offs')
    .eq('id', adrId)
    .single();

  if (error || !adr) throw new Error('ADR not found');

  const updated: SignOff[] = [
    ...(adr.sign_offs ?? []),
    { ...signOff, signedAt: new Date().toISOString() },
  ];

  await supabase
    .from('adrs')
    .update({ sign_offs: updated, updated_at: new Date().toISOString() })
    .eq('id', adrId);
}

// List ADRs for the current client — paginated
export async function listADRs(opts?: {
  page?: number;
  pageSize?: number;
  status?: ADRStatus;
}): Promise<{ adrs: ADRRecord[]; total: number }> {
  const config = await getClientConfig();
  const page = opts?.page ?? 0;
  const pageSize = opts?.pageSize ?? 20;

  let query = supabase
    .from('adrs')
    .select('*', { count: 'exact' })
    .eq('client_id', config.clientId)
    .order('created_at', { ascending: false })
    .range(page * pageSize, (page + 1) * pageSize - 1);

  if (opts?.status) query = query.eq('status', opts.status);

  const { data, count, error } = await query;
  if (error) throw new Error(`Failed to list ADRs: ${error.message}`);

  return { adrs: (data ?? []).map(toADRRecord), total: count ?? 0 };
}

// ── Internal helpers ────────────────────────────────────────────────────────

async function getNextVersion(clientId: string, requirement: string): Promise<number> {
  const { count } = await supabase
    .from('adrs')
    .select('*', { count: 'exact', head: true })
    .eq('client_id', clientId)
    .eq('requirement_hash', hashRequirement(requirement));

  return (count ?? 0) + 1;
}

function hashRequirement(req: string): string {
  // Simple deterministic hash — good enough for version grouping
  let hash = 0;
  for (let i = 0; i < req.length; i++) {
    hash = (Math.imul(31, hash) + req.charCodeAt(i)) | 0;
  }
  return Math.abs(hash).toString(36);
}

function toADRRecord(row: Record<string, unknown>): ADRRecord {
  return {
    id: row.id as string,
    clientId: row.client_id as string,
    sessionId: row.session_id as string,
    version: row.version as number,
    status: row.status as ADRStatus,
    requirement: row.requirement as string,
    verdict: row.verdict as string,
    scribeNotes: row.scribe_notes as string,
    mustFixIssues: (row.must_fix_issues as string[]) ?? [],
    signOffs: (row.sign_offs as SignOff[]) ?? [],
    createdAt: row.created_at as string,
    updatedAt: row.updated_at as string,
    supersededById: row.superseded_by_id as string | undefined,
  };
}
