# CLAUDE CODE INSTRUCTIONS — ARBoard production changes
# Paste this entire file as your first message to Claude Code.
# Claude Code will implement all changes in sequence.

---

I have an existing ARBoard Next.js 14 app (TypeScript, App Router, Tailwind, Anthropic SDK).
I need you to implement the following production changes using the code files I'll provide.
Do them in order — each step depends on the previous one.

## Step 1 — Install dependencies

```bash
npm install next-auth@beta @supabase/supabase-js
```

## Step 2 — Add these new files (I'll paste the contents)

Copy each file to its path exactly as shown:

- `lib/clients/types.ts`
- `lib/clients/index.ts`
- `lib/clients/acme-bank/config.ts`  ← rename acme-bank to your actual first client
- `lib/middleware/injectClientContext.ts`
- `lib/middleware/costGuard.ts`
- `lib/auth/config.ts`
- `lib/auth/rbac.ts`
- `lib/adr/store.ts`
- `middleware.ts`  ← goes in the project root

## Step 3 — Update app/api/forum/route.ts

Replace the existing route with the new version. Then:
1. Find your existing `runForum()` call inside it
2. Add `injectClientContext` to enrich each agent's system prompt before passing to runForum
3. Add `recordSessionCost()` in the stream completion callback
4. Add `saveADR()` in the stream completion callback after extracting verdict + scribeNotes

## Step 4 — Set up env vars

Copy `.env.local.template` to `.env.local` and fill in:
- `CLIENT_ID` = your client folder name
- `ANTHROPIC_API_KEY` = existing key
- `SUPABASE_URL` and `SUPABASE_ANON_KEY` = from your Supabase project
- `NEXTAUTH_SECRET` = run `openssl rand -base64 32`
- At least one auth provider (Azure AD recommended)

## Step 5 — Run Supabase SQL

In your Supabase SQL editor, run the CREATE TABLE and RLS policy SQL
from the comment block at the bottom of `app/api/forum/route.ts`.

## Step 6 — Verify

Run `npm run dev` and confirm:
- Unauthenticated access to / redirects to /auth/signin
- Authenticated users can reach the main forum
- A forum session completes and a row appears in the `adrs` table in Supabase
- A row appears in `session_costs` with the correct cost

## What is NOT changing

- Agent configs and prompts — untouched
- Streaming forum logic — untouched
- Impact analyser — untouched
- UI components — untouched
- Export / HTML report — untouched

The new code is entirely additive — it wraps and extends, it doesn't replace.
