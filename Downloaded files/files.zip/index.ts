// lib/clients/index.ts
// Loads the correct ClientConfig at runtime based on CLIENT_ID env var.
// Add a new client = add a new folder + config.ts. No changes here.

import type { ClientConfig } from './types';

const configCache: Record<string, ClientConfig> = {};

export async function getClientConfig(): Promise<ClientConfig> {
  const clientId = process.env.CLIENT_ID;
  if (!clientId) throw new Error('CLIENT_ID env var is not set');

  if (configCache[clientId]) return configCache[clientId];

  try {
    const mod = await import(`./${clientId}/config`);
    configCache[clientId] = mod.default as ClientConfig;
    return configCache[clientId];
  } catch {
    throw new Error(`No client config found for CLIENT_ID="${clientId}". Expected: lib/clients/${clientId}/config.ts`);
  }
}

// Utility — get client agent overrides if they exist, otherwise empty array
export async function getClientAgentOverrides(clientId: string) {
  try {
    const mod = await import(`./${clientId}/agent-overrides`);
    return mod.default ?? [];
  } catch {
    return [];
  }
}
