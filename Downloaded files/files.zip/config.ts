// lib/clients/acme-bank/config.ts
// TEMPLATE — copy this folder, rename to {clientId}, fill in the fields.
// One folder per client deployment. This is the only file you edit per client.

import type { ClientConfig } from '../types';

const config: ClientConfig = {
  clientId: 'acme-bank',
  name: 'Acme Bank',
  industry: 'Financial Services',
  salesforceClouds: [
    'Financial Services Cloud',
    'Service Cloud',
    'Data Cloud',
    'Agentforce',
  ],
  regulatoryOverlays: ['FSC', 'GDPR', 'SOX'],
  dataRegion: 'eu-west-1',
  knowledgeBaseId: 'acme-bank',
  monthlyBudgetUSD: 200,
  budgetAlertPct: 80,
  alertWebhookUrl: process.env.SLACK_WEBHOOK_URL,
  zeroRetention: false,
};

export default config;
