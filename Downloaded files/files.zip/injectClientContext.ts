// lib/middleware/injectClientContext.ts
// Slots into the existing middleware pipeline after injectContext.
// Prepends cloud scope, industry, and regulatory flags to every agent system prompt.

import { getClientConfig, getClientAgentOverrides } from '../clients';
import type { AgentPromptOverride } from '../clients/types';

interface MiddlewareInput {
  agentId: string;
  systemPrompt: string;
  clientId?: string;
}

export async function injectClientContext(input: MiddlewareInput): Promise<MiddlewareInput> {
  const config = await getClientConfig();
  const overrides: AgentPromptOverride[] = await getClientAgentOverrides(config.clientId);

  // Build the context prefix injected before every agent's system prompt
  const contextPrefix = buildContextPrefix(config);

  // Apply any client-specific section overrides for this agent
  const override = overrides.find(o => o.agentId === input.agentId);
  const overrideSuffix = override ? buildOverrideSuffix(override) : '';

  return {
    ...input,
    systemPrompt: [contextPrefix, input.systemPrompt, overrideSuffix]
      .filter(Boolean)
      .join('\n\n'),
  };
}

function buildContextPrefix(config: ReturnType<typeof Object.assign>): string {
  const lines = [
    `== CLIENT CONTEXT ==`,
    `Client: ${config.name} (${config.industry})`,
    `Salesforce clouds in scope: ${config.salesforceClouds.join(', ')}`,
  ];

  if (config.regulatoryOverlays.length > 0) {
    lines.push(`Regulatory overlays: ${config.regulatoryOverlays.join(', ')}`);
    lines.push(
      `IMPORTANT: All recommendations must comply with the above regulatory frameworks. ` +
      `Flag any design that creates compliance risk as a MUST-FIX issue.`
    );
  }

  lines.push(`== END CLIENT CONTEXT ==`);
  return lines.join('\n');
}

function buildOverrideSuffix(override: AgentPromptOverride): string {
  const parts = Object.entries(override.sections)
    .filter(([, v]) => v)
    .map(([k, v]) => `== CLIENT OVERRIDE: ${k.toUpperCase()} ==\n${v}`);
  return parts.join('\n\n');
}
