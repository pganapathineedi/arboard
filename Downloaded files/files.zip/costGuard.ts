// lib/middleware/costGuard.ts
// Tracks token spend per client against their monthly budget.
// Blocks sessions when the cap is breached. Fires a webhook alert at the threshold.
// Requires: SUPABASE_URL and SUPABASE_ANON_KEY env vars.

import { createClient } from '@supabase/supabase-js';
import { getClientConfig } from '../clients';

// Approximate cost per 1k tokens for claude-haiku-4-5 (update if pricing changes)
const COST_PER_1K_INPUT  = 0.00025; // USD
const COST_PER_1K_OUTPUT = 0.00125; // USD

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_ANON_KEY!
);

export interface TokenUsage {
  inputTokens: number;
  outputTokens: number;
}

// Call this BEFORE starting a forum session
export async function checkBudget(): Promise<{ allowed: boolean; reason?: string }> {
  const config = await getClientConfig();
  const spent = await getMonthlySpend(config.clientId);
  const remaining = config.monthlyBudgetUSD - spent;

  if (remaining <= 0) {
    return {
      allowed: false,
      reason: `Monthly budget of $${config.monthlyBudgetUSD} has been reached. Contact your administrator to increase the limit.`,
    };
  }
  return { allowed: true };
}

// Call this AFTER a forum session completes with actual token counts
export async function recordSessionCost(
  sessionId: string,
  usage: TokenUsage
): Promise<void> {
  const config = await getClientConfig();
  const cost = calculateCost(usage);

  await supabase.from('session_costs').insert({
    session_id: sessionId,
    client_id: config.clientId,
    input_tokens: usage.inputTokens,
    output_tokens: usage.outputTokens,
    cost_usd: cost,
    recorded_at: new Date().toISOString(),
  });

  // Check if we've crossed the alert threshold and fire webhook if so
  await maybeFireBudgetAlert(config, cost);
}

// ── Internal helpers ────────────────────────────────────────────────────────

function calculateCost(usage: TokenUsage): number {
  return (
    (usage.inputTokens  / 1000) * COST_PER_1K_INPUT +
    (usage.outputTokens / 1000) * COST_PER_1K_OUTPUT
  );
}

async function getMonthlySpend(clientId: string): Promise<number> {
  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);

  const { data, error } = await supabase
    .from('session_costs')
    .select('cost_usd')
    .eq('client_id', clientId)
    .gte('recorded_at', startOfMonth.toISOString());

  if (error) {
    console.error('costGuard: failed to read spend', error);
    return 0; // fail open — don't block sessions on DB errors
  }

  return (data ?? []).reduce((sum, row) => sum + (row.cost_usd ?? 0), 0);
}

async function maybeFireBudgetAlert(
  config: Awaited<ReturnType<typeof getClientConfig>>,
  latestCost: number
): Promise<void> {
  if (!config.alertWebhookUrl) return;

  const spent = await getMonthlySpend(config.clientId);
  const pct = (spent / config.monthlyBudgetUSD) * 100;
  const threshold = config.budgetAlertPct;

  // Fire once when crossing the threshold (check if previous spend was below it)
  const prevPct = ((spent - latestCost) / config.monthlyBudgetUSD) * 100;
  if (prevPct < threshold && pct >= threshold) {
    await fetch(config.alertWebhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: `⚠️ ARBoard budget alert — ${config.name}: ${pct.toFixed(0)}% of monthly budget used ($${spent.toFixed(2)} / $${config.monthlyBudgetUSD}). Sessions will be blocked at 100%.`,
      }),
    }).catch(err => console.error('costGuard: webhook failed', err));
  }
}
