// lib/auth/rbac.ts
// Role-based access control helpers.
// Wrap any API route handler with withRole() to enforce permissions.

import { auth } from './config';
import type { UserRole } from '../clients/types';
import { NextResponse } from 'next/server';

// Role hierarchy: admin > reviewer > readonly
const ROLE_LEVELS: Record<UserRole, number> = {
  admin: 3,
  reviewer: 2,
  readonly: 1,
};

// Wrap an API route handler to require a minimum role
export function withRole(
  minRole: UserRole,
  handler: (req: Request, ctx: { userId: string; role: UserRole; clientId: string }) => Promise<Response>
) {
  return async (req: Request): Promise<Response> => {
    const session = await auth();

    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });
    }

    const user = session.user as { email?: string; clientId?: string; role?: UserRole };
    const role = user.role ?? 'readonly';
    const clientId = user.clientId ?? '';

    if (ROLE_LEVELS[role] < ROLE_LEVELS[minRole]) {
      return NextResponse.json(
        { error: `Requires role: ${minRole}. Your role: ${role}` },
        { status: 403 }
      );
    }

    return handler(req, {
      userId: user.email ?? 'unknown',
      role,
      clientId,
    });
  };
}

// Usage examples:
//
// Reviewer-only route (can run forums):
// export const POST = withRole('reviewer', async (req, { clientId }) => { ... });
//
// Admin-only route (config, billing):
// export const GET = withRole('admin', async (req, { userId }) => { ... });
//
// Any authenticated user (read-only views):
// export const GET = withRole('readonly', async (req, ctx) => { ... });
