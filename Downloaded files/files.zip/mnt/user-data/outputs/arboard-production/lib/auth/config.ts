// lib/auth/config.ts
// NextAuth.js v5 (Auth.js) configuration.
// Install first: npm install next-auth@beta
// Supports Azure AD (primary for enterprise) with Google as fallback.
// clientId is injected into the JWT so every API call is scoped automatically.

import NextAuth from 'next-auth';
import AzureAD from 'next-auth/providers/microsoft-entra-id';
import Google from 'next-auth/providers/google';
import type { Session } from 'next-auth';
import type { JWT } from 'next-auth/jwt';
import type { UserRole } from '../clients/types';

export const { handlers, auth, signIn, signOut } = NextAuth({
  providers: [
    AzureAD({
      clientId: process.env.AZURE_AD_CLIENT_ID!,
      clientSecret: process.env.AZURE_AD_CLIENT_SECRET!,
      tenantId: process.env.AZURE_AD_TENANT_ID!,
    }),
    Google({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
  ],

  callbacks: {
    // Inject clientId and role into the JWT on first sign-in
    async jwt({ token, user }): Promise<JWT> {
      if (user) {
        token.clientId = process.env.CLIENT_ID ?? 'unknown';
        token.role = resolveRole(user.email ?? '');
      }
      return token;
    },

    // Expose clientId and role on the session object
    async session({ session, token }): Promise<Session> {
      if (session.user) {
        (session.user as Session['user'] & { clientId: string; role: UserRole }).clientId =
          token.clientId as string;
        (session.user as Session['user'] & { clientId: string; role: UserRole }).role =
          token.role as UserRole;
      }
      return session;
    },
  },

  pages: {
    signIn: '/auth/signin',
    error: '/auth/error',
  },
});

// ── Role resolution ──────────────────────────────────────────────────────────
// Extend this to read roles from your IdP groups or a DB table.
// For now: admins listed explicitly, everyone else is reviewer.

function resolveRole(email: string): UserRole {
  const adminEmails = (process.env.ADMIN_EMAILS ?? '').split(',').map(e => e.trim());
  const readonlyDomains = (process.env.READONLY_DOMAINS ?? '').split(',').map(d => d.trim());

  if (adminEmails.includes(email)) return 'admin';
  if (readonlyDomains.some(d => email.endsWith(`@${d}`))) return 'readonly';
  return 'reviewer';
}
